from django.urls import path
from .views import hello_world_view_function

urlpatterns=[
                              path('hello/',hello_world_view_function,name='hello')
]