from django.http import JsonResponse


def hello_world_view_function(request):
                              return JsonResponse({'message':'Hello world from EC2!'})